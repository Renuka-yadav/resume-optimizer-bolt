import streamlit as st
from resume_parser import extract_resume_text
from jd_matcher import match_resume_to_jd
from keyword_analyzer import missing_keywords
from score_generator import generate_score
from ai_suggester import get_resume_suggestions

st.title("📝 Resume Optimization Tool")

resume_file = st.file_uploader("Upload your resume", type=["pdf", "docx"])
jd_text = st.text_area("Paste Job Description")

if resume_file and jd_text:
    with open(f"resumes/{resume_file.name}", "wb") as f:
        f.write(resume_file.read())
    
    resume_text = extract_resume_text(f"resumes/{resume_file.name}")
    similarity = match_resume_to_jd(resume_text, jd_text)
    missing = missing_keywords(resume_text, jd_text)
    score = generate_score(similarity, missing)
    #suggestions = get_resume_suggestions(resume_text, jd_text)

    st.subheader("🔍 Match Score")
    st.metric("Similarity Score (%)", similarity)
    st.metric("Final Score", score)

    st.subheader("❌ Missing Keywords")
    st.write(", ".join(missing))

    st.subheader("💡 Suggestions to Improve Resume")
    st.write(suggestions)
