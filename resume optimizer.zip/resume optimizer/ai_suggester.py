from openai import OpenAI

# Initialize the OpenAI client with your API key
client = OpenAI(api_key="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")  # Replace with your actual key

# ✅ Wrap the prompt and API call in a function
def get_resume_suggestions(resume_text, jd_text):
    prompt = f"""
    You are a resume optimization expert. Analyze the following resume and job description.
    Give clear, specific suggestions to improve the resume to better match the job.

    Resume:
    {resume_text}

    Job Description:
    {jd_text}
    """

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )

    reply = response.choices[0].message.content
    return reply
