import openai

openai.api_key = "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"

def rewrite_resume(resume_text, jd_text):
    prompt = f"""You are a professional resume editor.
Rewrite the following resume to make it more aligned with the job description.
Only change wording and structure, don’t invent fake experience.

Resume:
{resume_text}

Job Description:
{jd_text}

Return only the rewritten resume:"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )

    return response.choices[0].message.content
